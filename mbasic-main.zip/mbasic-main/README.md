# install
pkg update && pkg upgrade
pkg instal git
pkg instal figlet
pkg instal python-pip
pip instal lolcat
cd $HOME
cd
git clone https://github.com/hxnsahasan/mbasic/tree/main
cd mbasic
chmod +x *
git pull
python brayen.py
scv2.py
mbasic2.py
